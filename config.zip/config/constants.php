<?php

return [
	'QUICKPAY_API_KEY'		=> 'ae6c729e07722f588663d4e16ca3d12ee7936789c4103b616374142a8c4872f3',
	'QUICKPAY_PRIVATE_KEY'	=> '33d987739f01e5fdbbaf893d20fbf98067d7b36ce059e757ea3f22fae32f214c',
	'NO_REPLY_EMAIL'		=> 'donotreply@swappi.dk',
	'ADMIN_EMAIL'			=> 'swappi@swappi.dk',
	'INFO_EMAIL'			=>	'info@swappi.dk',
	'MAILCHIMP_API_KEY'			=> '5a36e4305e4e394f3796ad23be40b06c-us9',
	'MAILCHIMP_LIST_ID'			=> '938b3db644'
];