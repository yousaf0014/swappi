<?php

namespace Illuminate\Contracts\Bus;

/**
 * @deprecated since version 5.2. Remove from jobs since self-handling is default.
 */
interface SelfHandling
{
    //
}
