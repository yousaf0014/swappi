<?php

namespace Intervention\Image\Exception;

class RuntimeException extends ImageException
{
    # nothing to override
}
